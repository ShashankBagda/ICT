import TestPackage.*;

class Main extends  Mypack
{
	public static void main(String s[])
	{
		Mypack t1 = new Mypack();
		t1.display();
	}
}
