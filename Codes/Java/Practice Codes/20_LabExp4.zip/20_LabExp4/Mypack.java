package TestPackage; 

public class Mypack
{
    public void display() 
        {
            System.out.println("User Defined Package"); 
        }  
}